class Question{

  String questionText;
  bool questionAnswer;

  Question({this.questionText,this.questionAnswer});
}